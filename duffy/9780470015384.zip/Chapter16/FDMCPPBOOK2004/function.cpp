
// function.cpp
//
//	Last modification dates:
//
//	2000-11-11 DD kick-off; function overloading
//
// (C) Datasim Component Technology BV 2000

#include "function.hpp"

