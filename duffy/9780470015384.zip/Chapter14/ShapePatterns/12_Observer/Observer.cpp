// Observer.cpp
//
// (C) Datasim Education BV 2001

#include "Observer.hpp"

Observer::Observer()
{// Default constructor
}

Observer::~Observer()
{// Destructor
}


