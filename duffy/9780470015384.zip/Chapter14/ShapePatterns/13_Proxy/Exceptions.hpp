// Exceptions.hpp
//
// (C) Datasim Education BV 2002

#ifndef Exceptions_hpp
#define Exceptions_hpp

class Exception
{
};

class NoFundsException: public Exception
{
};

class NoAccessException: public Exception
{
};

#endif
