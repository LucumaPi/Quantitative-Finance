// Common.hpp
//
// Header file with common includes

#ifndef Common_hpp
#define Common_hpp

#include <cmath>
#include <iostream>

#define PI 3.1415926535

#endif	// Common_hpp