The LU decomposition code is in the directory:
Utilities\Algebra

N.B. due to time constraints�
The code for pol + rat interpolation will be on my web site.
